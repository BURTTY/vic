<?php
require 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? 'user'; // default to 'user'

    // Check if username is taken
    $checkStmt = $pdo->prepare("SELECT id FROM users WHERE username = :username");
    $checkStmt->execute(['username' => $username]);
    if ($checkStmt->rowCount() > 0) {
        $error = "Username already exists. Please choose another.";
    } else {
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (:username, :password, :role)");
        $stmt->execute([
            'username' => $username,
            'password' => $hashedPassword,
            'role'     => $role
        ]);

        header("Location: index.php?registered=1");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Fira+Code&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            transition: 0.3s ease;
        }

        body {
            margin: 0;
            height: 100vh;
            background: linear-gradient(135deg,hsl(221, 66.30%, 34.90%), #011f44);
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        body.dark {
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
        }

        .blob {
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            filter: blur(60px);
            animation: float 10s ease-in-out infinite;
        }

        .blob:nth-child(1) {
            top: -100px;
            left: -100px;
        }

        .blob:nth-child(2) {
            bottom: -100px;
            right: -150px;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-30px); }
        }

        .container {
            display: flex;
            width: 90%;
            max-width: 1100px;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(15px);
            border-radius: 25px;
            box-shadow: 0 0 30px rgba(0,0,0,0.2);
            overflow: hidden;
            flex-wrap: wrap;
        }

        .left, .right {
            padding: 60px 40px;
            flex: 1;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: transparent;
        }

        .left h1 {
            font-size: 42px;
            animation: typewriter 3s steps(40) 1s 1 normal both;
            white-space: nowrap;
            overflow: hidden;
            border-right: 2px solid white;
            font-family: 'Fira Code', monospace;
        }

        @keyframes typewriter {
            from { width: 0; }
            to { width: 100%; }
        }

        .left p {
            font-size: 18px;
            opacity: 0.8;
        }

        .right {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(20px);
            border-left: 2px solid rgba(255,255,255,0.2);
        }

        body.dark .right {
            background: rgba(0, 0, 0, 0.4);
            color: #eee;
        }

        h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        form input, form select {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 15px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            background: rgba(255,255,255,0.6);
            outline: none;
        }

        form button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #667eea, #764ba2);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(118, 75, 162, 0.6); }
            70% { box-shadow: 0 0 0 10px rgba(118, 75, 162, 0); }
            100% { box-shadow: 0 0 0 0 rgba(118, 75, 162, 0); }
        }

        .right p {
            margin-top: 15px;
            font-size: 14px;
        }

        .right a {
            color: #764ba2;
            text-decoration: none;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .toggle-mode {
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            font-size: 18px;
        }

        /* Responsive styles */
        @media (max-width: 1024px) {
            .container {
                flex-direction: column;
                padding: 20px;
            }

            .left, .right {
                padding: 30px 20px;
            }

            .left h1 {
                font-size: 36px;
            }

            .right h2 {
                font-size: 24px;
            }

            form input, form select, form button {
                padding: 10px;
                font-size: 14px;
            }
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                padding: 20px;
            }

            .left, .right {
                padding: 20px;
            }

            .left h1 {
                font-size: 32px;
            }

            form input, form select, form button {
                padding: 12px 8px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 15px;
            }

            .left h1 {
                font-size: 28px;
            }

            form input, form select, form button {
                font-size: 14px;
                padding: 8px 10px;
            }

            .left p, .right p {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="blob"></div>
    <div class="blob"></div>

    <div class="container">
        <div class="left">
            <h1>Welcome to the Registration</h1>
            <p>Fill in the form to create your account</p>
        </div>
        
        <div class="right">
            <h2>Register</h2>
            <form action="register.php" method="POST">
                <?php if (!empty($error)): ?>
                    <div class="error"><?php echo $error; ?></div>
                <?php endif; ?>

                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <select name="role">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <button type="submit">Register</button>
            </form>

            <p>Already have an account? <a href="index.php">Login here</a></p>
        </div>
    </div>

    <div class="toggle-mode" onclick="toggleDarkMode()">🌙</div>

    <script>
        function toggleDarkMode() {
            document.body.classList.toggle('dark');
        }
    </script>
</body>
</html>
