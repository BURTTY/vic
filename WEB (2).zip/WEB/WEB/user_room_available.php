<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit;
}

$selectedDate = $_POST['date'] ?? '';
$selectedTimeIn = $_POST['time_in'] ?? '';
$selectedTimeOut = $_POST['time_out'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM rooms ORDER BY building, room_number");
$stmt->execute();
$allRooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

$availableRooms = [];
$buildingRoomsCount = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0]; // Track rooms per building

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($allRooms as $room) {
        if ($buildingRoomsCount[$room['building']] < 10) { // Limit to 10 per building
            $checkStmt = $pdo->prepare("
                SELECT COUNT(*) FROM reservations
                WHERE building = :building
                AND room_number = :room_number
                AND date = :date
                AND (
                    (time_in <= :time_in AND time_out > :time_in) OR 
                    (time_in < :time_out AND time_out >= :time_out) OR
                    (time_in >= :time_in AND time_out <= :time_out)
                )
            ");
            $checkStmt->execute([
                'building' => $room['building'],
                'room_number' => $room['room_number'],
                'date' => $selectedDate,
                'time_in' => $selectedTimeIn,
                'time_out' => $selectedTimeOut
            ]);

            $isBooked = $checkStmt->fetchColumn();

            if ($isBooked == 0) {
                $availableRooms[] = $room;
                $buildingRoomsCount[$room['building']]++; // Increase count for the building
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Available Rooms</title>
    
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg,hsl(221, 66.30%, 34.90%), #011f44);
            color: #333;
            font-size: 16px;
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            display: flex;
            width: 90%;
            max-width: 1200px;
            gap: 40px;
        }

        /* Left section for form (fixed width) */
        .form-container {
            width: 40%;  /* Increased width */
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-out;
            text-align: center;
        }

        h1 {
            color: #011f44;
            font-size: 28px;
            margin-bottom: 30px;
            font-weight: 600;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;  /* Increased gap between fields */
        }

        label {
            font-size: 16px;
            color: #333;
            text-align: left;
            font-weight: 500;
        }

        input[type="date"],
        input[type="time"] {
            padding: 15px;  /* Increased padding for more space */
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f7f7f7;
            transition: border-color 0.3s;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="date"]:focus,
        input[type="time"]:focus {
            border-color: #011f44;
            outline: none;
        }

        button[type="submit"] {
            background-color: #011f44;
            color: white;
            font-size: 18px;
            padding: 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
            width: 100%;
            font-weight: bold;
        }

        button[type="submit"]:hover {
            background-color: #005a8d;
            transform: translateY(-2px);
        }

        /* Right Section: Available rooms (Flexible width) */
        .rooms-container {
            width: 55%;  /* Adjusted width */
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-out;
            overflow-y: auto;
            max-height: 80vh;
            padding-right: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            opacity: 0;
            animation: fadeIn 1s ease-out forwards;
        }

        th, td {
            padding: 15px;  /* Increased padding for better spacing */
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #011f44;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        p {
            color: red;
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
        }

        /* Fade In Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                gap: 20px;
            }

            .form-container, .rooms-container {
                width: 100%;
            }

            button[type="submit"] {
                font-size: 16px;
                padding: 10px;
            }

            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <!-- Left Section: Form for selecting date/time -->
        <div class="form-container">
            <h1>Check Available Rooms</h1>
            <form method="POST" action="">
                <label for="date">Date:</label>
                <input type="date" name="date" value="<?php echo $selectedDate; ?>" required>

                <label for="time_in">Time In:</label>
                <input type="time" name="time_in" value="<?php echo $selectedTimeIn; ?>" required>

                <label for="time_out">Time Out:</label>
                <input type="time" name="time_out" value="<?php echo $selectedTimeOut; ?>" required>

                <button type="submit">Check Availability</button>
            </form>
        </div>

        <!-- Right Section: Display Available Rooms -->
        <div class="rooms-container">
            <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                <h2>Available Rooms</h2>
                <?php if (count($availableRooms) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Building</th>
                                <th>Room Number</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($availableRooms as $room): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($room['building']); ?></td>
                                    <td><?php echo htmlspecialchars($room['room_number']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No rooms available for the selected date/time.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>
