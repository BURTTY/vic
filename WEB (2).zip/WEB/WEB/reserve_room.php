<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserve a Room</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg,hsl(221, 66.30%, 34.90%), #011f44);
            background-size: 200% 200%;
            animation: gradientBackground 6s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: hidden;
            opacity: 0;
            animation: fadeIn 1s forwards;
        }

        .container {
            background-color: #fff;
            width: 100%;
            max-width: 500px; /* Reduced width */
            padding: 25px; /* Reduced padding */
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease-in-out;
            transform: translateY(20px);
            animation: slideUp 0.6s ease-out forwards;
        }

        .container:hover {
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            font-size: 2rem; /* Reduced font size */
            margin-bottom: 15px; /* Reduced margin */
            color: #2c3e50;
            font-weight: 700;
            text-transform: uppercase;
            opacity: 0;
            animation: fadeIn 1s ease 0.3s forwards;
        }

        p {
            text-align: center;
            color: #7a8a92;
            margin-bottom: 20px; /* Reduced margin */
            font-size: 0.9rem; /* Reduced font size */
            opacity: 0;
            animation: fadeIn 1s ease 0.5s forwards;
        }

        .input-group {
            margin-bottom: 18px; /* Reduced space between input fields */
            position: relative;
            opacity: 0;
            animation: fadeIn 1s ease 0.7s forwards;
        }

        .input-group label {
            font-size: 14px;
            color: #4e5b6e;
            position: absolute;
            top: -12px;
            left: 10px;
            background-color: #fff;
            padding: 0 5px;
            font-weight: 500;
        }

        .input-group select,
        .input-group input {
            width: 100%;
            padding: 12px; /* Reduced padding */
            font-size: 14px; /* Smaller font size */
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fafafa;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
        }

        .input-group select:focus,
        .input-group input:focus {
            border-color: #3498db;
            outline: none;
            background-color: #fff;
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.2);
        }

        .input-group select:invalid,
        .input-group input:invalid {
            border-color: #e74c3c;
        }

        .error {
            color: #e74c3c;
            font-size: 12px;
            margin-top: 5px;
        }

        button {
    width: 100%;
    color: white;
    padding: 14px; /* Reduced padding */
    font-size: 16px; /* Reduced font size */
    border: none; /* Ensure no border */
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out, transform 0.2s ease;
    opacity: 0;
    animation: fadeIn 1s ease 1s forwards;
    outline: none; /* Ensure no outline */
    box-shadow: none !important; /* Remove any shadow */
}

.back-btn {
    position: absolute;
    top: 20px;
    left: 20px;
    font-size: 18px; /* Larger font size for visibility */
    color: #fff; /* White text color */
    padding: 12px 24px; /* More padding for better clickable area */
    border-radius: 8px; /* Rounded corners */
    display: flex;
    align-items: center; /* Center the icon and text vertically */
    cursor: pointer;
    border: none; /* Remove any border */
    outline: none; /* Remove the focus outline */
    box-shadow: none !important; /* Ensure no shadow around the button */
    transition: background-color 0.3s ease, transform 0.2s ease, opacity 0.2s ease;
}

/* Ensuring the arrow icon is properly sized */
.back-btn i {
    font-size: 24px; /* Increased size of the arrow */
    margin-right: 10px; /* More space between the icon and text */
}

/* Link styling for the text */
.back-btn a {
    color: #fff; /* White text for the link */
    font-size: 18px; /* Consistent font size with the button */
    text-decoration: none;
    margin-left: 8px;
    transition: color 0.3s ease;
}

/* Hover effects for the button */
.back-btn:hover {
    transform: translateY(-3px); /* Subtle lift effect */
    opacity: 0.9; /* Slight opacity reduction on hover */
}

/* Hover effects for the link */
.back-btn a:hover {
    color: #ecf0f1; /* Lighter color on hover */
    text-decoration: underline;
}




        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideUp {
            from {
                transform: translateY(20px);
            }
            to {
                transform: translateY(0);
            }
        }

        @keyframes gradientBackground {
            0% {
                background-position: 200% 200%;
            }
            50% {
                background-position: 0% 0%;
            }
            100% {
                background-position: 200% 200%;
            }
        }
    </style>
</head>
<body>
    <div class="back-btn">
        <i class="fa fa-arrow-left"></i><a href="user_dashboard.php">BACK</a>
    </div>

    <div class="container">
        <h1>Reserve a Room</h1>
        <p>Please fill out the form below to reserve a room.</p>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="input-group">
                <label>Building:</label>
                <select name="building" required id="building">
                    <option value="A">Building A</option>
                    <option value="B">Building B</option>
                    <option value="C">Building C</option>
                    <option value="D">Building D</option>
                </select>
            </div>

            <div class="input-group">
                <label>Room Number:</label>
                <select name="room_number" required id="room_number">
                    <option value="">Select a Building First</option>
                </select>
            </div>

            <div class="input-group">
                <label>Date:</label>
                <input type="date" name="date" required>
            </div>

            <div class="input-group">
                <label>Time In:</label>
                <input type="time" name="time_in" required>
            </div>

            <div class="input-group">
                <label>Time Out:</label>
                <input type="time" name="time_out" required>
            </div>

            <div class="input-group">
                <label>Section:</label>
                <input type="text" name="section" required>
            </div>

            <button type="submit">Reserve</button>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let timeIn = document.querySelector('input[name="time_in"]');
            let timeOut = document.querySelector('input[name="time_out"]');

            // Set min and max time range
            timeIn.setAttribute("min", "08:00");
            timeIn.setAttribute("max", "17:00");
            timeOut.setAttribute("min", "08:00");
            timeOut.setAttribute("max", "17:00");

            document.querySelector('form').addEventListener("submit", function(e) {
                if (timeIn.value < "08:00" || timeIn.value > "17:00" || timeOut.value < "08:00" || timeOut.value > "17:00") {
                    e.preventDefault();
                    alert("Time must be between 8:00 AM and 5:00 PM.");
                }
            });

            // Fetch room numbers based on selected building
            document.getElementById('building').addEventListener('change', function () {
                let building = this.value;
                let roomDropdown = document.getElementById('room_number');

                fetch(`fetch_rooms.php?building=${building}`)
                    .then(response => response.json())
                    .then(data => {
                        roomDropdown.innerHTML = '<option value="">Select a Room</option>';
                        data.forEach(room => {
                            roomDropdown.innerHTML += `<option value="${room.room_number}">${room.room_number}</option>`;
                        });
                    });
            });
        });
    </script>
</body>
</html>
