<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!$id) {
    header("Location: admin_room_record.php");
    exit;
}

// Fetch current reservation
$stmt = $pdo->prepare("SELECT * FROM reservations WHERE id = :id");
$stmt->execute(['id' => $id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation) {
    header("Location: admin_room_record.php");
    exit;
}

// Fetch available rooms
$roomsStmt = $pdo->prepare("SELECT * FROM rooms");
$roomsStmt->execute();
$rooms = $roomsStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $building = $_POST['building'] ?? '';
    $room_number = $_POST['room_number'] ?? '';
    $date = $_POST['date'] ?? '';
    $time_in = $_POST['time_in'] ?? '';
    $time_out = $_POST['time_out'] ?? '';
    $section = $_POST['section'] ?? '';

    // Check for overlapping reservations
    $checkStmt = $pdo->prepare("
        SELECT * FROM reservations
        WHERE id != :id
        AND building = :building
        AND room_number = :room_number
        AND date = :date
        AND (
            (time_in < :time_out AND time_out > :time_in)
        )
    ");
    $checkStmt->execute([
        'id' => $id,
        'building' => $building,
        'room_number' => $room_number,
        'date' => $date,
        'time_in' => $time_in,
        'time_out' => $time_out
    ]);

    if ($checkStmt->rowCount() > 0) {
        $error = "Conflict with an existing reservation!";
    } else {
        // Update reservation
        $updateStmt = $pdo->prepare("
            UPDATE reservations
            SET building = :building,
                room_number = :room_number,
                date = :date,
                time_in = :time_in,
                time_out = :time_out,
                section = :section
            WHERE id = :id
        ");
        $updateStmt->execute([
            'building' => $building,
            'room_number' => $room_number,
            'date' => $date,
            'time_in' => $time_in,
            'time_out' => $time_out,
            'section' => $section,
            'id' => $id
        ]);
        header("Location: admin_room_record.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Re-Schedule Reservation</title>
    <link rel="stylesheet" href="CSS/resched.css">
</head>
<body>
    <div class="form-container">
        <h2>Re-Schedule Reservation</h2>
        <p class="form-subtitle">Reservation #<?php echo $reservation['id']; ?></p>
        <?php if (!empty($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST" action="">
            <label>Building:</label>
            <select name="building">
                <option value="A" <?php if($reservation['building'] === 'A') echo 'selected'; ?>>A</option>
                <option value="B" <?php if($reservation['building'] === 'B') echo 'selected'; ?>>B</option>
                <option value="C" <?php if($reservation['building'] === 'C') echo 'selected'; ?>>C</option>
                <option value="D" <?php if($reservation['building'] === 'D') echo 'selected'; ?>>D</option>
            </select>

            <label>Room Number:</label>
            <select name="room_number" required>
                <?php foreach ($rooms as $room): ?>
                    <option value="<?php echo $room['room_number']; ?>" <?php if ($room['room_number'] == $reservation['room_number']) echo 'selected'; ?>>
                        Room <?php echo $room['room_number']; ?> (Building <?php echo $room['building']; ?>)
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Date:</label>
            <input type="date" name="date" value="<?php echo $reservation['date']; ?>" required>

            <label>Time In:</label>
            <input type="time" name="time_in" value="<?php echo $reservation['time_in']; ?>" required>

            <label>Time Out:</label>
            <input type="time" name="time_out" value="<?php echo $reservation['time_out']; ?>" required>

            <label>Section:</label>
            <input type="text" name="section" value="<?php echo $reservation['section']; ?>">

            <button type="submit">Save Changes</button>
        </form>
        <a href="admin_room_record.php" class="back-link">Back</a>
    </div>
</body>
</html>
