<?php
session_start();
require 'db_connect.php';

// Ensure the user is logged in and has the correct role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit;
}

// Fetch all reservations for the logged-in user
$stmt = $pdo->prepare("
    SELECT r.*, u.username 
    FROM reservations r
    JOIN users u ON r.user_id = u.id
    WHERE r.user_id = ?
    ORDER BY r.date, r.time_in
");
$stmt->execute([$_SESSION['user_id']]);
$reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle cancellation of a reservation
if (isset($_GET['cancel_id'])) {
    $cancel_id = $_GET['cancel_id'];
    
    // Prepare and execute the cancellation query
    $cancel_stmt = $pdo->prepare("DELETE FROM reservations WHERE id = ?");
    $cancel_stmt->execute([$cancel_id]);
    
    // Redirect to the same page after cancellation
    header("Location: user_room_record.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Room Reservations</title>
    <!-- Include Font Awesome for the arrow icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Global Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: linear-gradient(135deg, hsl(221, 66.30%, 34.90%), #011f44);
            color: #333;
            font-size: 16px;
            line-height: 1.5;
        }

        /* Container */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            position: relative;
        }

        /* Heading */
        h1 {
            text-align: center;
            font-size: 30px;
            margin-bottom: 20px;
            color: #2d3436;
        }

        /* Notification */
        .notification {
            background-color: #fff3cd;
            padding: 10px;
            margin-bottom: 20px;
            color: #856404;
            border-radius: 5px;
            font-size: 14px;
            text-align: center;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            opacity: 0;
            animation: fadeIn 1s ease-out forwards;
        }

        th, td {
            padding: 14px 18px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #011f44;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f7f7f7;
        }

        tr:hover {
            background-color: #e1f5fe;
        }

        /* Back to Dashboard Button */
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            color: #011f44;
            font-size: 24px;
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border: none;
            background: none;
            transition: color 0.3s ease, transform 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
        }

        .back-button:hover {
            color: #f1c40f;
            transform: translateX(-5px);
        }

        .back-button:hover i {
            transform: rotate(-180deg);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Cancel Button Style */
        .cancel-btn {
            padding: 5px 10px;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .cancel-btn:hover {
            background-color: #c0392b;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                width: 95%;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 10px;
            }

            .back-button {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Back to Dashboard Button with Arrow -->
        <a href="user_dashboard.php" class="back-button">
            <i class="fas fa-arrow-left"></i> Back
        </a>

        <h1>My Room Reservations</h1>
        <div class="notification">
            <p>⚠️ Please check your reservations carefully.</p>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Building</th>
                    <th>Room</th>
                    <th>Date</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                    <th>Section</th>
                    <th>Booked By</th>
                    <th>Action</th> <!-- Add an action column for cancel -->
                </tr>
            </thead>
            <tbody>
                <?php if (count($reservations) > 0): ?>
                    <?php foreach($reservations as $res): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($res['building']); ?></td>
                        <td><?php echo htmlspecialchars($res['room_number']); ?></td>
                        <td><?php echo htmlspecialchars($res['date']); ?></td>
                        <td><?php echo htmlspecialchars($res['time_in']); ?></td>
                        <td><?php echo htmlspecialchars($res['time_out']); ?></td>
                        <td><?php echo htmlspecialchars($res['section']); ?></td>
                        <td><?php echo htmlspecialchars($res['username']); ?></td>
                        <td>
                            <!-- Cancel Button with confirmation -->
                            <a href="user_room_record.php?cancel_id=<?php echo $res['id']; ?>" 
                               onclick="return confirm('Are you sure you want to cancel this reservation?');" class="cancel-btn">
                                Cancel
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">No reservations found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
