<?php
    session_start();
    require 'db_connect.php';
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header("Location: index.php");
        exit;
    }

    // Handle the search input
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    // Pagination settings
    $items_per_page = 10; // Number of records per page
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $items_per_page;

    // Fetch reservations with optional search filter and pagination
    $query = "SELECT * FROM reservations";
    if (!empty($search)) {
        $query .= " WHERE user_id LIKE :search OR building LIKE :search OR room_number LIKE :search OR section LIKE :search OR date LIKE :search";
    }
    $query .= " ORDER BY date, time_in LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($query);
    if (!empty($search)) {
        $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    }
    $stmt->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get total number of reservations for pagination
    $total_query = "SELECT COUNT(*) FROM reservations";
    if (!empty($search)) {
        $total_query .= " WHERE user_id LIKE :search OR building LIKE :search OR room_number LIKE :search OR section LIKE :search OR date LIKE :search";
    }
    $total_stmt = $pdo->prepare($total_query);
    if (!empty($search)) {
        $total_stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    }
    $total_stmt->execute();
    $total_reservations = $total_stmt->fetchColumn();
    $total_pages = ceil($total_reservations / $items_per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Reservations</title>
    <link rel="stylesheet" href="CSS/Drecord.css">
</head>
<body>
    <div class="container">
        <h1>All Room Reservations</h1>

        <div class="search-container">
            <form method="GET">
                <input type="text" name="search" placeholder="Search by User ID, Building, Room, Section, Date" value="<?php echo htmlspecialchars($search); ?>">
            </form>
        </div>

        <table>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Building</th>
                <th>Room</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Section</th>
                <th>Actions</th>
            </tr>
            <?php foreach($reservations as $res): ?>
            <tr>
                <td><?php echo $res['id']; ?></td>
                <td><?php echo $res['user_id']; ?></td>
                <td><?php echo $res['building']; ?></td>
                <td><?php echo $res['room_number']; ?></td>
                <td><?php echo $res['date']; ?></td>
                <td><?php echo $res['time_in']; ?></td>
                <td><?php echo $res['time_out']; ?></td>
                <td><?php echo $res['section']; ?></td>
                <td>
                    <a href="reschedule.php?id=<?php echo $res['id']; ?>" class="btn btn-edit">Re-Schedule</a>
                    <a href="remove.php?id=<?php echo $res['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure?');">Remove</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>

        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo htmlspecialchars($search); ?>" class="btn btn-prev">Back</a>
            <?php endif; ?>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo htmlspecialchars($search); ?>" class="btn btn-next">Next</a>
            <?php endif; ?>
        </div>

        <div class="back-button">
            <a href="admin_dashboard.php" class="btn btn-back">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
