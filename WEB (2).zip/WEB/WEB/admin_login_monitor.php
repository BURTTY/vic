<?php
session_start();
require 'db_connect.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Fetch login records
$stmt = $pdo->query("SELECT * FROM login_logs ORDER BY login_time DESC");
$logins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Monitor</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Global Styles */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #ecf0f1;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            color: #34495e;
        }

        .dashboard-container {
            display: flex;
            width: 100%;
            height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #111827; /* Dark background */
            color: #fff;
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            height: 100%;
        }

        .sidebar h2 {
            font-size: 1.6em;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .sidebar a {
            color: #fff;
            display: flex;
            align-items: center;
            text-decoration: none;
            font-size: 1.1em;
            margin: 15px 0;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a i {
            margin-right: 10px; /* Space between icon and text */
        }

        .sidebar a:hover {
            background-color: #1f2937; /* Grayish dark */
        }

        /* Content Area Styles */
        .content-area {
            flex-grow: 1;
            padding: 30px;
            background-color: #f7fafc; /* Light background */
            overflow-y: auto;
        }

        h1 {
            color: #111827;
            margin-bottom: 20px;
            font-size: 1.8em;
            font-weight: 600;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #2c3e50;
            color: #fff;
        }

        td {
            background-color: #ecf0f1;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                height: auto;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="sidebar">
            <h2>ADMIN</h2>
            <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard </a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </div>

        <div class="content-area">
            <h1>Login Monitor</h1>
            <table>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Login Time</th>
                </tr>
                <?php foreach ($logins as $log): ?>
                <tr>
                    <td><?php echo htmlspecialchars($log['username']); ?></td>
                    <td><?php echo htmlspecialchars($log['role']); ?></td>
                    <td><?php echo htmlspecialchars($log['login_time']); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>