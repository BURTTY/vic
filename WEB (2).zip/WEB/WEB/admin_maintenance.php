<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
require 'db_connect.php';

// Add Room
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_room'])) {
    $building = $_POST['building'];
    $room_number = $_POST['room_number'];

    $stmt = $pdo->prepare("INSERT INTO rooms (building, room_number, status) VALUES (:building, :room_number, 'active')");
    if ($stmt->execute(['building' => $building, 'room_number' => $room_number])) {
        $message = ["Room added successfully!", "success"];
    } else {
        $message = ["Error adding room.", "error"];
    }
}

// Enable/Disable Room
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['toggle_status'])) {
    $room_id = $_POST['room_id'];
    $current_status = $_POST['current_status'];
    $new_status = $current_status === 'active' ? 'inactive' : 'active';

    $stmt = $pdo->prepare("UPDATE rooms SET status = :status WHERE id = :room_id");
    if ($stmt->execute(['status' => $new_status, 'room_id' => $room_id])) {
        $message = ["Room marked as " . ucfirst($new_status) . ".", "success"];
    } else {
        $message = ["Error updating room status.", "error"];
    }
}

// Fetch Rooms
$stmt = $pdo->query("SELECT * FROM rooms ORDER BY building, room_number");
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Global Styles */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #ecf0f1;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            display: flex;
            height: 100vh;
            color: #34495e;
        }

        .dashboard-container {
            display: flex;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #111827; /* Dark background */
            color: #fff;
            padding: 20px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            height: 100%;
        }

        .sidebar h2 {
            font-size: 1.6em;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .sidebar-link {
            color: #fff;
            display: block;
            text-decoration: none;
            font-size: 1.1em;
            margin: 15px 0;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar-link:hover {
            background-color: #1f2937; /* Grayish dark */
        }

        /* Content Area Styles */
        .content-area {
            flex-grow: 1;
            padding: 30px;
            background-color: #f7fafc; /* Light background */
            overflow-y: auto;
        }

        h1, h2 {
            color: #111827;
            margin-bottom: 20px;
            font-size: 1.8em;
            font-weight: 600;
        }

        /* Message Styles */
        .message {
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 5px;
            font-weight: bold;
        }

        .message.success {
            background-color: #2ecc71;
            color: #1e824c;
        }

        .message.error {
            background-color: #e74c3c;
            color: #c0392b;
        }

        /* Form Section Styles */
        .form-section {
            background-color: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0 , 0.1);
            margin-bottom: 30px;
        }

        .form-section label {
            display: block;
            margin-bottom: 10px;
            font-weight: 500;
        }

        .form-section select, .form-section input {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1em;
        }

        .form-section button {
            padding: 15px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-section button:hover {
            background-color: #2980b9;
        }

        /* Table Section Styles */
        .table-section {
            background-color: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        input[type="text"] {
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            font-size: 1em;
            margin-bottom: 20px;
            border: 1px solid #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #2c3e50;
            color: #fff;
        }

        table td {
            background-color: #ecf0f1;
        }

        .badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.9em;
        }

        .badge.active {
            background-color: #2ecc71;
            color: #fff;
        }

        .badge.inactive {
            background-color: #e74c3c;
            color: #fff;
        }

        .sidebar-link i {
            margin-right: 8px;
        }

        /* Button styles */
        .button {
            padding: 10px 15px;
            border-radius: 5px;
            border: none;
            font-size: 1em;
            cursor: pointer;
            margin: 5px;
        }

        .button-enable {
            background-color: #2ecc71;
            color: white;
        }

        .button-enable:hover {
            background-color: #27ae60;
        }

        .button-disable {
            background-color: #e74c3c;
            color: white;
        }

        .button-disable:hover {
            background-color: #c0392b;
        }

        .button-disabled {
            background-color: #bdc3c7;
            color: white;
            cursor: not-allowed;
        }
    </style>
</head>
<body>

<div class="dashboard-container">
    <div class="sidebar">
        <h2>ADMIN</h2>
        <a href="admin_dashboard.php" class="sidebar-link"><i class="fas fa-home"></i> Dashboard</a>
        <a href="logout.php" class="sidebar-link"><i class="fas fa-sign-out-alt"></i> Log Out</a>
    </div>

    <div class="content-area">
        <h1>Maintenance Dashboard</h1>

        <?php if (isset($message)): ?>
            <div class="message <?= $message[1]; ?>"><?= $message[0]; ?></div>
        <?php endif; ?>

        <!-- Add Room Form -->
        <div class="form-section">
            <h2>Add a Room</h2>
            <form method="POST">
                <label>Building:</label>
                <select name="building" required>
                    <option value="">--Select--</option>
                    <option value="A">Building A</option>
                    <option value="B">Building B</option>
                    <option value="C">Building C</option>
                    <option value="D">Building D</option>
                </select>
                <label>Room Number:</label>
                <input type="text" name="room_number" required>
                <button type="submit" name="add_room"><i class="fas fa-plus"></i> Add Room</button>
            </form>
        </div>

        <!-- Search & Room Table -->
        <div class="table-section">
            <h2>Existing Rooms</h2>
            <input type="text" id="roomSearch" placeholder="Search by building or number..." onkeyup="filterRooms()">

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Building</th>
                        <th>Room Number</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rooms as $room): ?>
                    <tr class="<?= $room['status'] === 'inactive' ? 'inactive' : ''; ?>">
                        <td><?= $room['id']; ?></td>
                        <td><?= $room['building']; ?></td>
                        <td><?= $room['room_number']; ?></td>
                        <td>
                            <span class="badge <?= $room['status']; ?>">
                                <?= ucfirst($room['status']); ?>
                            </span>
                        </td>
                        <td>
                            <form method="POST" onsubmit="return confirmToggle('<?= $room['status']; ?>')">
                                <input type="hidden" name="room_id" value="<?= $room['id']; ?>">
                                <input type="hidden" name="current_status" value="<?= $room['status']; ?>">
                                <button type="submit" name="toggle_status" class="button <?= $room['status'] === 'active' ? 'button-disable' : 'button-enable'; ?>" <?= $room['status'] === 'inactive' ? '' : 'disabled'; ?>>
                                    <?= $room['status'] === 'active' ? 'Disable' : 'Enable'; ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    function filterRooms() {
        let input = document.getElementById('roomSearch');
        let filter = input.value.toLowerCase();
        let rows = document.querySelectorAll('table tbody tr');
        
        rows.forEach(row => {
            let text = row.textContent || row.innerText;
            row.style.display = text.toLowerCase().includes(filter) ? '' : 'none';
        });
    }

    function confirmToggle(status) {
        return confirm("Are you sure you want to change the status of this room?");
    }
</script>

</body>
</html>