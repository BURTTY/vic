<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit;
}
date_default_timezone_set('Asia/Manila');
$hour = date('H');
$greeting = ($hour < 12) ? 'Good Morning' : (($hour < 18) ? 'Good Afternoon' : 'Good Evening');
$username = htmlspecialchars($_SESSION['username']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Add Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --bg-light: #f9fafb;
            --bg-dark: #1f2937;
            --text-light: #111827;
            --text-dark: #f3f4f6;
            --accent: #3b82f6;
            --hover-bg: #e0f2fe;
            --warning-bg: #fff3cd;
            --warning-text: #856404;
            --transition-speed: 0.4s; /* Animation speed */
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-light);
            transition: background-color var(--transition-speed), color var(--transition-speed);
        }

        body.dark-theme {
            background-color: var(--bg-dark);
            color: var(--text-dark);
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
            transition: transform var(--transition-speed);
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1e293b, #0f172a);
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            color: white;
            box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
            transition: all var(--transition-speed);
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 15px;
            color: #e5e7eb;
            text-decoration: none;
            border-radius: 10px;
            transition: background var(--transition-speed), transform 0.2s ease-in-out;
        }

        .sidebar a:hover {
            background-color: #334155;
            transform: translateX(5px) scale(1.05);
        }

        .logout-btn {
            margin-top: auto;
            color: white !important;
            text-align: center;
            border-radius: 8px;
            padding: 10px 0;
            transition: background-color var(--transition-speed);
        }

        .content-area {
            flex-grow: 1;
            padding: 40px 50px;
            background-color: var(--bg-light);
            transition: background-color var(--transition-speed);
        }

        .content-area.dark-theme {
            background-color: #2d3748;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all var(--transition-speed);
        }

        .header h1 {
            font-size: 28px;
            transition: color var(--transition-speed);
        }

        .theme-toggle {
            cursor: pointer;
            background: none;
            border: 2px solid var(--accent);
            padding: 5px 12px;
            border-radius: 25px;
            color: var(--accent);
            font-size: 14px;
            transition: background-color var(--transition-speed), transform 0.2s ease;
        }

        .theme-toggle:hover {
            background-color: var(--hover-bg);
            transform: scale(1.05);
        }

        .notification {
            margin-top: 30px;
            padding: 20px;
            background-color: var(--warning-bg);
            border-left: 6px solid #ffc107;
            border-radius: 8px;
            color: var(--warning-text);
            font-size: 15px;
            max-width: 600px;
            animation: slideIn 0.5s ease-out;
        }

        .admin-notes {
            margin-top: 20px;
            padding: 20px;
            background-color: #d1e7dd;
            border-left: 6px solid #0f5132;
            border-radius: 8px;
            color: #0f5132;
            font-size: 15px;
            max-width: 600px;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            0% {
                transform: translateY(-20px);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: space-around;
                gap: 10px;
            }
            .content-area {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2><i class="fas fa-book-open"></i> STUDENT</h2>
            <a href="reserve_room.php"><i class="fas fa-calendar-day"></i> Room Reservation</a>
            <a href="user_room_record.php"><i class="fas fa-scroll"></i> Room Record</a>
            <a href="user_room_available.php"><i class="fas fa-check-circle"></i> Room Availability</a>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </div>

        <!-- Main Content -->
        <div class="content-area">
            <div class="header">
                <h1><?= $greeting ?>, <strong><?= $username ?></strong>! 👋</h1>
                <button class="theme-toggle"><i class="fas fa-moon"></i> Toggle Theme</button>
            </div>
            <p style="margin-top: 10px; color: #64748b;">
                Welcome to your dashboard! Quickly check available rooms or manage your reservations below.
            </p>

            <!-- User Notes / Reminder -->
            <div class="notification">
                ⚠️ <strong>Reminder:</strong> If you no longer need a room reservation, please cancel it to free up the slot for others.
            </div>

            <!-- Admin Notes (for user dashboard) -->
            <div class="admin-notes">
                📢 <strong>Note from Admin:</strong> Please ensure that you are booking rooms only for your academic use. Room misuse will lead to restrictions.
            </div>
        </div>
    </div>

    <script>
        // Theme toggle functionality
        const toggleBtn = document.querySelector('.theme-toggle');
        toggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            document.querySelector('.content-area').classList.toggle('dark-theme');
            const isDarkMode = document.body.classList.contains('dark-theme');
            toggleBtn.innerHTML = isDarkMode ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
            document.body.style.transition = 'background-color 0.3s, color 0.3s';
        });
    </script>
</body>
</html>
