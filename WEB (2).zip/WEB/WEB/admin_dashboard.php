<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <!-- External CSS -->
    <link rel="stylesheet" href="CSS/adminD.css">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-light: #f9fafb;
            --bg-dark: #1f2937;
            --text-light: #111827;
            --text-dark: #f3f4f6;
            --accent: #3b82f6;
            --hover-bg: #e0f2fe;
            --warning-bg: #fff3cd;
            --warning-text: #856404;
            --transition-speed: 0.4s;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-light);
            transition: background-color var(--transition-speed), color var(--transition-speed);
        }

        body.dark-theme {
            background-color: var(--bg-dark);
            color: var(--text-dark);
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
            transition: transform var(--transition-speed);
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1e293b, #0f172a);
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            color: white;
            box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
            transition: all var(--transition-speed);
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 15px;
            color: #e5e7eb;
            text-decoration: none;
            border-radius: 10px;
            transition: background var(--transition-speed), transform 0.2s ease-in-out;
        }

        .sidebar a:hover {
            background-color: #334155;
            transform: translateX(5px) scale(1.05);
        }

        .sidebar h2 {
            color: white;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .logout {
            margin-top: auto;
            color: white;
            text-align: center;
            border-radius: 8px;
            padding: 10px 0;
            transition: background-color var(--transition-speed);
        }

        .content-area {
            flex-grow: 1;
            padding: 40px 50px;
            background-color: var(--bg-light);
            transition: background-color var(--transition-speed);
        }

        .content-area.dark-theme {
            background-color: #2d3748;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all var(--transition-speed);
        }

        .header h1 {
            font-size: 28px;
            transition: color var(--transition-speed);
        }

        .theme-toggle {
            cursor: pointer;
            background: none;
            border: 2px solid var(--accent);
            padding: 5px 12px;
            border-radius: 25px;
            color: var(--accent);
            font-size: 14px;
            transition: background-color var(--transition-speed), transform 0.2s ease;
        }

        .theme-toggle:hover {
            background-color: var(--hover-bg);
            transform: scale(1.05);
        }

        .menu-toggle {
            display: none;
            font-size: 30px;
            background-color: transparent;
            color: #333;
            border: none;
            cursor: pointer;
        }

        .dashboard-cards {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            transition: all var(--transition-speed);
        }

        .dashboard-info {
            flex: 1;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, background-color var(--transition-speed);
        }

        .dashboard-info:hover {
            transform: translateY(-10px);
            background-color: var(--hover-bg);
        }

        .dashboard-info h3 {
            margin-top: 0;
            font-size: 20px;
            color: #333;
        }

        .dashboard-info p {
            font-size: 16px;
            color: #666;
        }

        @media (max-width: 768px) {
            .dashboard-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: space-around;
                gap: 10px;
                display: none;
            }

            .sidebar.active {
                display: flex;
            }

            .content-area {
                padding: 30px 20px;
            }

            .menu-toggle {
                display: block;
            }
        }

        /* Card enhancements */
        .card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex-basis: calc(33.33% - 20px);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-title {
            font-size: 20px;
            color: #333;
        }

        .card-content {
            font-size: 16px;
            color: #666;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        
        <!-- Sidebar Navigation -->
        <div class="sidebar" id="sidebar">
            <h2>ADMIN</h2>
            <a href="admin_room_record.php" class="sidebar-link"><i class="fas fa-calendar-check"></i> Room Record</a>
            <a href="admin_login_monitor.php" class="sidebar-link"><i class="fas fa-chart-line"></i> Login Monitor</a>
            <a href="admin_maintenance.php" class="sidebar-link"><i class="fas fa-tools"></i> Maintenance</a>
            <a href="logout.php" class="sidebar-link logout"><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </div>

        <!-- Main Content Area -->
        <div class="content-area">
            <div class="header">
                <h1>Welcome back, <span class="admin-name"><?php echo htmlspecialchars($_SESSION['username']); ?></span> 👋</h1>
                <button class="theme-toggle"><i class="fas fa-moon"></i> Toggle Theme</button>
            </div>

            <div class="dashboard-cards">
                <div class="card">
                    <h3 class="card-title">Room Record</h3>
                    <p class="card-content">Manage and view room reservations, cancellations, and updates.</p>
                </div>
                <div class="card">
                    <h3 class="card-title">Login Monitor</h3>
                    <p class="card-content">Monitor user logins and manage access records.</p>
                </div>
                <div class="card">
                    <h3 class="card-title">Maintenance</h3>
                    <p class="card-content">Perform routine maintenance tasks to ensure smooth operations.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JS for Sidebar Toggle -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }

        // Theme toggle functionality
        const toggleBtn = document.querySelector('.theme-toggle');
        toggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            document.querySelector('.content-area').classList.toggle('dark-theme');
            const isDarkMode = document.body.classList.contains('dark-theme');
            toggleBtn.innerHTML = isDarkMode ? '<i class="fas fa-sun"></i> Light Mode' : '<i class="fas fa-moon"></i> Dark Mode';
            document.body.style.transition = 'background-color 0.3s, color 0.3s';
        });
    </script>

</body>
</html>
