<?php
session_start();
require 'db_connect.php';

if (isset($_SESSION['role'])) {
    header("Location: " . ($_SESSION['role'] === 'admin' ? "admin_dashboard.php" : "user_dashboard.php"));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND role = :role");
    $stmt->execute(['username' => $username, 'role' => $role]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        $stmt = $pdo->prepare("INSERT INTO login_logs (user_id, username, role) VALUES (:user_id, :username, :role)");
        $stmt->execute([ 
            'user_id' => $user['id'], 
            'username' => $user['username'], 
            'role' => $user['role'] 
        ]);

        echo "<script>
            localStorage.setItem('loginSuccess', '1');
            window.location.href = '" . ($user['role'] === 'admin' ? "admin_dashboard.php" : "user_dashboard.php") . "';
        </script>";
        exit;
    } else {
        $error = "Invalid username, password, or role.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Room Booking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Fira+Code&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
            transition: 0.3s ease;
        }

        body {
            margin: 0;
            height: 100vh;
            background: linear-gradient(135deg,hsl(221, 66.30%, 34.90%), #011f44);
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        body.dark {
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
        }

        .blob {
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            filter: blur(60px);
            animation: float 10s ease-in-out infinite;
        }

        .blob:nth-child(1) {
            top: -100px;
            left: -100px;
        }

        .blob:nth-child(2) {
            bottom: -100px;
            right: -150px;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-30px); }
        }

        .container {
            display: flex;
            width: 90%;
            max-width: 1100px;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(15px);
            border-radius: 25px;
            box-shadow: 0 0 30px rgba(0,0,0,0.2);
            overflow: hidden;
            flex-direction: row;
        }

        .left {
            flex: 1;
            padding: 60px 40px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: transparent;
        }

        .left h1 {
            font-size: 42px;
            animation: typewriter 3s steps(40) 1s 1 normal both;
            white-space: nowrap;
            overflow: hidden;
            border-right: 2px solid white;
            font-family: 'Fira Code', monospace;
        }

        @keyframes typewriter {
            from { width: 0; }
            to { width: 100%; }
        }

        .left p {
            font-size: 18px;
            opacity: 0.8;
        }

        .right {
            flex: 1;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(20px);
            border-left: 2px solid rgba(255,255,255,0.2);
            animation: fadeIn 1s ease-in;
        }

        body.dark .right {
            background: rgba(0, 0, 0, 0.4);
            color: #eee;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        form input, form select {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 15px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            background: rgba(255,255,255,0.6);
            outline: none;
        }

        form button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #667eea, #764ba2);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(118, 75, 162, 0.6); }
            70% { box-shadow: 0 0 0 10px rgba(118, 75, 162, 0); }
            100% { box-shadow: 0 0 0 0 rgba(118, 75, 162, 0); }
        }

        .right p {
            margin-top: 15px;
            font-size: 14px;
        }

        .right a {
            color: #764ba2;
            text-decoration: none;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .toast {
            position: absolute;
            top: 20px;
            right: 20px;
            background: #4BB543;
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
            display: none;
        }

        .toggle-mode {
            position: absolute;
            top: 20px;
            left: 20px;
            cursor: pointer;
            font-size: 18px;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .toggle-mode {
                top: 10px;
                left: 50%;
                transform: translateX(-50%);
            }

            .left h1 {
                font-size: 28px;
            }

            .left p {
                font-size: 14px;
            }

            .right h2 {
                font-size: 22px;
            }

            form input, form select {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="blob"></div>
    <div class="blob"></div>

    <div class="toggle-mode" onclick="toggleMode()">🌙</div>
    

    <div class="container">
        <div class="left">
            <h1>Welcome to Room Scheduler</h1>
            <p>Plan, Book, and Track rooms easily. Log in below.</p>
        </div>
        <div class="right">
            <h2>Login</h2>
            <?php if (!empty($error)): ?>
                <p class="error"><?= $error ?></p>
            <?php endif; ?>
            <form method="POST" onsubmit="showLoading(this)">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                </select>
                <button type="submit"><span class="btn-text">Log In</span></button>
            </form>
            <p>Don't have an account? <a href="register.php">Register</a></p>
        </div>
    </div>

    <script>
        function toggleMode() {
            document.body.classList.toggle('dark');
        }

        function showLoading(form) {
            const button = form.querySelector('button .btn-text');
            if (button) button.textContent = 'Logging in...';
        }

        window.addEventListener('load', () => {
            if (localStorage.getItem('loginSuccess') === '1') {
                const toast = document.getElementById('toast');
                toast.style.display = 'block';
                setTimeout(() => {
                    toast.style.display = 'none';
                    localStorage.removeItem('loginSuccess');
                }, 3000);
            }
        });
    </script>
</body>
</html>
