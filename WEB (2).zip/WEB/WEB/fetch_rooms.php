<?php
require 'db_connect.php';

$building = $_GET['building'] ?? '';

if ($building) {
    $stmt = $pdo->prepare("SELECT room_number FROM rooms WHERE building = :building");
    $stmt->execute(['building' => $building]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
?>